package AmazonPages;

import org.openqa.selenium.By;

public class HomePage {
	
	public static By accountList=By.xpath("//a[@id='nav-link-accountList']");
	public static By signin=By.xpath("//*[@id=\"nav-flyout-ya-signin\"]/a/span");
	public static By verifyAccount=By.xpath("//a[@id='nav-your-amazon']/span/span");
	public static  By continueButton = By.xpath("//input[@id='continue']");

}
