package com.Buffer;

import java.util.List;
import java.util.Map;

public class BufferUtilMethodLevel {

	public static Map<String, String> bufferMap;

	public static List<String> bufferListforString;

	public static String testCaseName;

	public static String testCasePriority;

	public static String caseIDNumber;

	public static String caseNumber;
}
