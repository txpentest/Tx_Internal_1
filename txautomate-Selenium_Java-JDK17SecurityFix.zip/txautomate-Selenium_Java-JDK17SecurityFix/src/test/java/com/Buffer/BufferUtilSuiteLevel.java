package com.Buffer;

import java.util.List;
import java.util.Map;

public class BufferUtilSuiteLevel {

	public static Map<String, String> bufferMapSuiteLevel;

	public static List<String> bufferListforStringSuiteLevel;

	public static String configurationValueFromMvnCommand;

	public static String environmentValueFromMvnCommand;

	public static String executionEnvironment;

	public static String platformName;

	public static String operatingSystem;

	public static String browserName;

	public static String JIRAissueID;

	public static String screenshotFilePath;

	public static String extentHtmlreportWithNameAndPath;
}
