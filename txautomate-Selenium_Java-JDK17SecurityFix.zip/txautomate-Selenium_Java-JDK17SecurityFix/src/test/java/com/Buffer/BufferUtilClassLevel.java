package com.Buffer;

import java.util.List;
import java.util.Map;

public class BufferUtilClassLevel {

	public static Map<String, String> bufferMapClassLevel;

	public static List<String> bufferListforStringClassLevel;

}
